About
=============================================
This is an implementation of a "Wordle" game in MIPS assembly language, created for the final project for CS 2340 Honors Computer Architecture by Jerry Wang
